qqqqqqq8 修复补丁包
目标仓库：liquorcloud0818-create/qqqqqqq8
目标分支：main

本补丁处理两条独立链路：
1. 照片发送：发送被拦截或中途失败时不再提前关闭弹窗；按成功数量移除已发送照片，未发送照片保留，避免丢图和重复发送。原有多图、GIF、实况照片处理保留。
2. APK 文件导出：网页 downloadFile 检测自定义 AndroidShell 原生桥，将 Blob 分块传输到 Android；Android 10+ 保存到公共 Downloads/Float，Android 8/9 保存到应用专属 Downloads。失败会中止并清理未完成文件。
3. Android 文件选择：补充解析 Intent.clipData，兼容多选图片。
4. Android 下载按 255 KiB 分块（块大小是 3 的倍数），避免独立 Base64 分块带 padding 后直接拼接导致 ZIP 内容损坏。
5. APK 版本号提升到 1.0.1 / versionCode 2，确保新 APK 可覆盖安装旧版。

应用方式：
1. 将压缩包解压到 qqqqqqq8 仓库根目录，确保出现 qqqqqqq8_fix 文件夹。
2. 在仓库根目录执行：
   bash qqqqqqq8_fix/apply-fixes.sh
3. 检查 git diff 和 git diff --check，确认后再提交、推送 main。

注意：
- 这是一组待应用的源代码补丁，不代表已经推送到 GitHub，也不代表已经生成 APK。
- Android 10 及以上文件会出现在系统“下载/Float”目录；Android 8/9 因 scoped storage 前置限制，保存于应用专属外部下载目录。
- 本环境当前无法运行 Android SDK/Gradle，也无法进行真机验证。必须同时部署新版网页并安装重新构建的 1.0.1 APK（仅部署网页不能给旧 APK 增加原生接口），再实际测试单张/多张照片发送、GIF、备份 ZIP 导出和其他 Blob 下载。
- 如果 git apply 提示上下文不匹配，先确认 main 分支文件 SHA 与本补丁对应的版本一致，不要强行覆盖。
