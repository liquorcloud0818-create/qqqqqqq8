#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "$0")" && pwd)/patches"
PATCHES=(
  "$PATCH_DIR/0001-photo-send.patch"
  "$PATCH_DIR/0002-android-download.patch"
  "$PATCH_DIR/0003-android-shell-native.patch"
  "$PATCH_DIR/0004-android-version.patch"
)

for patch in "${PATCHES[@]}"; do
  git apply --check "$patch"
done
for patch in "${PATCHES[@]}"; do
  git apply "$patch"
done
git diff --check
printf '
补丁已应用。请检查 git diff，再提交并推送到 main。
'
